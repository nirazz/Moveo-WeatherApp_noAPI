import React, { useState, useEffect, useRef } from 'react';
import './App.css';


function App() {
	const [weather, setWeather] = useState(null);
	const [city, setCity] = useState('Tel aviv');
	const input = useRef(null);

	async function onSend() {
		await fetchData(input.current.value);
		setCity(input.current.value);
	}
	useEffect(() => {
		async function fetchData(query) {
			query = query ? `?city=${query}` : '';
			const res = await fetch(`http://localhost:4000/data${query}`);
			const data = await res.json();
			setWeather(data);
		}
		fetchData();
	}, []);

	async function fetchData(query) {
		query = query ? `?city=${query}` : '';
		const res = await fetch(`http://localhost:4000/data${query}`);
		const data = await res.json();
		setWeather(data);
	}

	if (!weather) return 'Loading...';

	return (
		<div className="App">
			<h1>Planning a trip soon? Do a weather check! &#9757;</h1>
            <p class="lead">Enter Your Destination Below:</p>
			<input ref={input} type="text" />
			<button onClick={onSend}>Search</button>
			<div class="card">
				<img src={weather.img} alt="Avatar" />
				<div class="container">
					<p>
					<b>Location: {city}</b>
					</p>
					<p>Temperature: {weather.temperature} --- Humidity: {weather.humidity} --- {weather.wind}{"km/h"}</p>
				</div>
			</div>
		</div>
	);
}

export default App;
