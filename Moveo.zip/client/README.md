Weather app:
This project is a weather app which finds the current weather in a chosen location.

Instructions:
Enter a location and press the "Search" button to see the current location weather.
