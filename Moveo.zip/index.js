const puppeteer = require('puppeteer');

// create http server
const express = require('express');
const app = express();

const cors = require('cors');
app.use(cors()); // allow browser to send a request to another domain

const url = 'https://www.timeanddate.com/weather';

// route - GET localhost:4000/data
app.get('/data', async (req, res) => {
	try {
		let { city } = req.query;
		city = city || 'tel aviv';
		console.log('city', city);
		const browser = await puppeteer.launch();
		const page = await browser.newPage();
		await page.goto(url);

		await page.focus('#sb_wc_q');
		await page.keyboard.type(city);
		await page.click(`button[type="submit"]`);
		await delay(2000);
		await page.click(`table.zebra tbody tr a`);
		await page.screenshot({ path: 'example2.png' });

		const data = await page.evaluate(() => {
			let str = document.querySelector('#qlook p:nth-child(6)').innerText;
			return {
				temperature: document.querySelector('#qlook div.h2').innerText,
				humidity: document.querySelector('table tbody tr:nth-child(6) td').innerText,
				wind: str.slice(str.lastIndexOf('Wind:'), str.lastIndexOf('km/h')),
				img: document.querySelector('img.headline-banner__flag').src,
			};
		});

		console.log('data', data);
		res.json(data); // send json to client

		await browser.close();
	} catch (err) {
		console.log('err', err.message);
		res.json({
			error: err.message,
		});
	}
});

app.listen(4000); // server run on port 4000

function delay(time) {
	return new Promise(function (resolve) {
		setTimeout(resolve, time);
	});
}
